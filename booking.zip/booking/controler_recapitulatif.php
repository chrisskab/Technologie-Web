<?php
//Appel de la classe Reservation
include_once("class_reservation.php");
//Reprise de la session courante
session_start();
//Si CONFIRM appuyé
if(isset($_POST['confirm'])){
    //Demande au routeur d'accéder à la page des infos de payement
	?>
		
		<form name="form" method="post" action="router.php">
			<input type="hidden" name="page" value="payement">
			<script type="text/javascript"> 
				document.forms["form"].submit();
			</script> 
		</form>
		
		<?php
        //Connexion à la base de données
        $mysqli = new mysqli("localhost", "root", "","reservation") or die("Could not select database"); //on se connecte à la base de donnée booking
if ($mysqli->connect_errno) {
  echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ")" . $mysqli->connect_error;
}
echo $mysqli->host_info."\n";
/*
Modification de la base de données

if(isset($_POST['id'])){
    $id=$_POST['id'];
  
  $sql= "UPDATE tbooking SET tnames='Bonjour' WHERE id='36' ";
if ($mysqli->query($sql) === TRUE) {
  echo"Record insertedsuccessfully";
}
else{
  echo"Errorupdatingrecord: " . $mysqli->error;
}
*/

// Insertion d'une nouvelles réservation dans la base de données
echo($_SESSION['reservation']->getAges()[0]);
$dest=$_SESSION['reservation']->getDestination();
$nb=$_SESSION['reservation']->getNombre();
$names=implode('.',$_SESSION['reservation']->getNames());
$ages=implode('.',$_SESSION['reservation']->getAges());
if($_SESSION['reservation']->getAssurance()){$ass=1;} else{$ass=0;}
$sql= "INSERT INTO tbooking (`tdestination`,`tnombre`,`tnames`,`tages`,`tassurance`)
                    VALUES ('$dest', '$nb', '$names','$ages', '$ass');";
if ($mysqli->query($sql) === TRUE) {
  echo"Record updatedsuccessfully";
  $id_insert= $mysqli->insert_id;
  }
else{echo"Errorinsertingrecord: " . $mysqli->error;}
       
}
//Si BACK appuyé, demande au routeur l'accès à la page précédente
if(isset($_POST['back'])){
	?>
		
		<form name="form" method="post" action="router.php">
			<input type="hidden" name="page" value="detail">
			<script type="text/javascript"> 
				document.forms["form"].submit();
			</script> 
		</form>
		
		<?php
}
//Si annulation, on supprime la réservation en cours en supprimant la session
//Et on revient à la page d'accueil
if(isset($_POST['cancel'])){
	session_destroy();
	?>
		
		<form name="form" method="post" action="router.php">
			<input type="hidden" name="page" value="accueil">
			<script type="text/javascript"> 
				document.forms["form"].submit();
			</script> 
		</form>
		
		<?php
}
//Par défault, on affiche la page reprenant le récapitulatif de la réservation.
else{
include 'view_recapitulatif.php';
}
?>