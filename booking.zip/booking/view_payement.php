<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<div class="container">

<form class="form-signin-heading" method="post" action="controler_payement.php">

 <h2>Confirmation des réservation</h2>
Votre demande a bien été enregistrée. </br>
Merci de bien vouloir verser 

<?php 
//Reprise de la session courante si il en existe une.
//Sinon, création d'une nouvelle session.
include_once("class_reservation.php");
if (version_compare(PHP_VERSION, '5.4.0', '<')) {
        if(session_id() == '') {session_start();}
    } else  {
       if (session_status() == PHP_SESSION_NONE) {session_start();}
    }
echo($_SESSION['reservation']->getPrix()); 

?> 


euros sur le compte 000-000000-00.
</br>
<input type="submit" class="btn btn-primary btn-block" name="home" value="Retour a la page d'accueil">
<input type="submit" class="btn btn-primary btn-block" name="admin" value="Liste des réservations">  
</form></div>