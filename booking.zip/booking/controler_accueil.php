<!-- Il s'agit du controleur de la page d'accueil.-->

<?php
include_once("class_reservation.php");
//Crée une nouvelle session s'il n'y a pas une existante
if (version_compare(PHP_VERSION, '5.4.0', '<')) {
        if(session_id() == '') {session_start();}
    } else  {
       if (session_status() == PHP_SESSION_NONE) {session_start();}
    }
//Crée un nouvel objet Reservation s'il n'y en a pas déjà un
//Sinon, récupère l'objet Reservation de la session active.
if (!isset($_SESSION["reservation"])){
    $reservation = new Reservation; //créer une instance de la classe Reservation
    $_SESSION["reservation"] = $reservation;
}

else {
    $reservation = $_SESSION["reservation"];
}
//Si on veut passer à la page suivante, l'objet Reservation est modifié
//et son état change et prend les valeurs entrées dans les champs
if(isset($_POST['next'])){//Si j'appuie sur suivant
	if(isset($_POST['nombre']) && isset($_POST['destination'])){
		if( $_POST['destination']!=null  && $_POST['nombre']<10 && $_POST['nombre']>=1){
		//Mise a jour de l'objet reservation-
			$reservation->setDestination(($_POST["destination"]));
			$reservation->setNombre(($_POST["nombre"]));
			if(isset($_POST["assurance"])){
				$reservation->setAssurance(TRUE);
			}
			else{
				$reservation->setAssurance(FALSE);
			}
            //Demande au routeur l'accès à la page des détails
			?>
		
			<form name="form" method="post" action="router.php">
				<input type="hidden" name="page" value="detail">
				<script type="text/javascript"> 
					document.forms["form"].submit();
				</script> 
			</form>
		
			<?php
		}
    //Vérifie si les champs entrés sont valables.
		elseif($_POST['destination']==null||$_POST['nombre']==null){
		include("messageerreur.php");
		include("view_accueil.php");
		}	
	}
}
//Si on veut annuler la réservation, le site renvoie simplement la même page avec champs vides.
	elseif(isset($_POST['cancel'])){
		include("view_accueil.php");
	}
 //Par défaut, on affiche la page d'accueil
	else{
		include("view_accueil.php");
		
	}
	
?>
