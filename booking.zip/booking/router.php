<?php

// En fonction de la page qu'on lui demande, le routeur renvoie vers le controleur
// de la page demandée.
if(!empty($_POST['page']) && is_file('controler_'.$_POST['page'].'.php'))
{
	include 'controler_'.$_POST['page'].'.php';
}
//Par défault, on envoie la page d'accueil
else{ 
	include 'controler_accueil.php';
}
?>