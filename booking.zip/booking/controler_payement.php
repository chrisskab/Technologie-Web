<?php
//Si on a appuyé sur HOME
if(isset($_POST['home'])){
    //Reprise de la session courante si il en existe une.
    //Sinon, création d'une nouvelle session.
	if (version_compare(PHP_VERSION, '5.4.0', '<')) {
        if(session_id() == '') {session_start();}
    } else  {
       if (session_status() == PHP_SESSION_NONE) {session_start();}
    }
	session_destroy();//Suppression de la session puisque la réservation est validée et enregistrée 
	//Demande au router l'accès à la page d'accueil.
    ?>
		
		<form name="form" method="post" action="router.php">
			<input type="hidden" name="page" value="accueil">
			<script type="text/javascript"> 
				document.forms["form"].submit();
			</script> 
		</form>
		
		<?php
}//Si on veut accéder à la liste des réservations
if(isset($_POST['admin'])){
    //Demande au routeur d'accéder à la page d'administration
	?>
		
		<form name="form" method="post" action="router.php">
			<input type="hidden" name="page" value="administration">
			<script type="text/javascript"> 
				document.forms["form"].submit();
			</script> 
		</form>
		
		<?php
}
//Par défault, on affiche la page contenant les infos de payement
else{
include('view_payement.php');
}
?>