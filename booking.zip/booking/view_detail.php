
<!--Voici la vue de la page des détails-->
<html>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<head>
	<title> RESERVATION </title>
</head>
<body>
<div class="container">
<!--Formulaires reprenant les noms et ages des différents voyageurs de la réservation
Les valeurs seront envoyées au et controlées par le controleur.-->

<form class="form-signin"  method="post" action="controler_detail.php">
<h1 class="form-signin-heading">Détail des réservations</h1>
<?php 
//Reprise de la session courante si il en existe une.
//Sinon, création d'une nouvelle session.
include_once("class_reservation.php");
if (version_compare(PHP_VERSION, '5.4.0', '<')) {
        if(session_id() == '') {session_start();}
    } else  {
       if (session_status() == PHP_SESSION_NONE) {session_start();}
    }
 
if(!empty($_SESSION['reservation']->getNames())){
    //Création d'autant de champs input qu'il y a de voyageurs
for ($i = 0; $i<$_SESSION["reservation"]->getNombre(); $i++){
	$namex='name'.$i;//Chaque voyageur a sa propre variable nom
	$agex='age'.$i;//Chaque voyageur a sa propre variable age

    			?>
	<table>
	<tr>
        <td><b>Voyageur <?php echo $i+1;?> </b></td>
   <tr>
        <td>Name</td>
      
	<td><input class="form-control" type="text" name="<?php
//Les valeurs par défaut sont celle contenues dans l'objet reservation de la session courante
    echo($namex); ?>" value="
	<?php 
	if(isset($_SESSION['reservation']->getNames()[$i])){
	echo($_SESSION['reservation']->getNames()[$i]);
	}
	else{echo("");}
	?>"/></td> </tr>
  <tr>
	<td>Age</td>
	<td><input class="form-control" type="text" name="<?php 
//Les valeurs par défaut sont celle contenues dans l'objet reservation de la session courante
    echo($agex); ?>" value="
	<?php 
	if(isset($_SESSION['reservation']->getAges()[$i])){
		echo($_SESSION['reservation']->getAges()[$i]);
	}
	else{
		echo("");
	}
	?>"/></td>
   </tr>
</br>

</table>
		<?php 
		}
}
	else{
		for ($i = 0; $i<$_SESSION["reservation"]->getNombre(); $i++){
	$namex='name'.$i;
	$agex='age'.$i;
    			?>
	<table>
	<tr>
        <td><b>Voyageur <?php echo $i+1;?> </b></td>
   <tr>
        <td>Name</td>
	<td><input class="form-control" type="text" name= '<?php echo($namex); ?>'/></td> </tr>
  <tr>
	<td>Age</td>
	<td><input class="form-control" type="number" name='<?php echo($agex); ?>'/></td>
   </tr>
</br>

</table>
		
</br>
<p></p>
<table>
<?php 
	
}
	}
	?>
<tr>
<td><input class="btn btn-primary btn-block" type="submit" name="next" value="Page Suivante"> </td>
<td><input class="btn btn-primary btn-block" type="submit" name="back" value="Retour à la page précédente"></td>
<td><input class="btn btn-primary btn-block" type="submit" name="cancel" value="Annuler la réservation"> </td>
</tr>
</table>
</form>
</div>
</body>