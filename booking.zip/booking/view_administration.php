<html>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<head>
	<title> RESERVATION </title>
</head>
<body>
<div class='container'>
<?php
$mysqli = new mysqli("localhost", "root", "","reservation") or die("Could not select database"); //on se connecte à la base de donnée booking
if ($mysqli->connect_errno) {
  echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ")" . $mysqli->connect_error;
}
//echo $mysqli->host_info."\n";


$query= "SELECT * FROM tbooking";
echo "\n";
$result= $mysqli->query($query) or die("Query failed");
while($row = $result->fetch_assoc()) {
					$reservations[] = $row; 
				}
if ($result->num_rows== 0)
{echo"Aucune ligne trouvée, rien à afficher.";exit;}

?>
<h1>Page d'administration</h1>
<form method="POST" action="controler_administration.php">
						<table class="table" border="1" >
						<tr>
						    <tr>
							<th>N° de réservation</th>
							<th>Destination</th>
							<th>Nombre de places</th>
							<th  COLSPAN=2 >Voyageurs</th>
							<th>Assurance
							<th>Total Price</th>
							<th></th>
							<th></th>
						</tr>
						<?php foreach($reservations as $reserv){ 
                        $names=explode(".",$reserv['tnames']);
                        $ages=explode(".",$reserv['tages']);
                        $id=$reserv['id'];
                        
                        ?>
								
						        <tr>
 									<td><?php echo $reserv['id']; ?></td>
									<td><?php echo $reserv['tdestination']; ?></td>
									<td><?php echo $reserv['tnombre']; ?></td>
									<td><?php foreach($names as $name){ 
                                    echo $name."\n";} ?></td>
									<td><?php foreach($ages as $age){ 
                                    echo $age."\n";} ?></td>
									<td><?php echo $reserv['tassurance']; ?></td>
									<td>prix </td>
                                    <td><button type="submit" name="delete" value="<?php echo $id; ?>">Delete</button></td>
									<td><button type="submit" name="edit"  value="<?php echo $id; ?>">Edit</button></td>
								</tr>
								<?php } ?>
						</table>
				</form>;
</div>
</body></html>