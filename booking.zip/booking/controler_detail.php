<?php
//Voici le controleur de la page des détails concernant les voyageurs
include_once("class_reservation.php");
//Si un session est déjà en cours, on la reprend. Sinon création d'une nouvelle session
if (version_compare(PHP_VERSION, '5.4.0', '<')) {
        if(session_id() == '') {session_start();}
    } else  {
       if (session_status() == PHP_SESSION_NONE) {session_start();}
    }
//Si on appuie sur le bouton NEXT
if(isset($_POST['next'])){
$empty=FALSE;
//Vérification que chaque champ input est bien rempli
	foreach($_POST as $key => $val){
		if ($val==null){
			$empty=TRUE;
			break;
		}
	}
    //Message d'erreur si champs input vide et on reste sur la même page
	if($empty){
		include("messageerreur2.php");
		include("view_detail.php");
	}
	
		else{
	//Si les conditons sont remplies, changement de l'état de mon objet de type Reservation
	for($i=0;$i<$_SESSION['reservation']->getNombre();$i++){
		$_SESSION['reservation']->addName($_POST["name".$i],$i); 
		$_SESSION['reservation']->addAge($_POST["age".$i],$i); 
		
	}
	//Envoi au routeur la demande d'accéder au récapitulatif
	?>
	
		<form name="form" method="post" action="router.php">
			<input type="hidden" name="page" value="recapitulatif">
			<script type="text/javascript"> 
				document.forms["form"].submit();
			</script> 
		</form>
		
		<?php
		}
	}
//Si BACK appuyé, demande au routeur d'accéder à la page précédente	
elseif(isset($_POST['back'])){
	?>
		
		<form name="form" method="post" action="router.php">
			<input type="hidden" name="page" value="accueil">
			<script type="text/javascript"> 
				document.forms["form"].submit();
			</script> 
		</form>
		
		<?php
}
//Si on veut annuler la réservation, suppression de la session
//Ensuite, demande au routeur l'accès à la page d'accueil
elseif(isset($_POST['cancel'])){
	session_destroy();
	?>
		
		<form name="form" method="post" action="router.php">
			<input type="hidden" name="page" value="accueil">
			<script type="text/javascript"> 
				document.forms["form"].submit();
			</script> 
		</form>
		
		<?php
}
//Par défaut, on affiche le formulaire des détails sur les voyageurs
else{
	
	include 'view_detail.php';
}

?>