<!-- Cette page contient le message d'erreur à inclure sur la page des détails--
concernant les voyageurs dans le cas où les conditions ne sont pas respectées-->

<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<html>
<p></p>
<div class="container">
<div class="jumbotron">
Veuillez entrer une destination.</br>
Veuillez entrer un nombre supérieur à 0 et inférieur à 10.</div></div>
<html>