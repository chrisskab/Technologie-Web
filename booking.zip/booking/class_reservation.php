<!-- 
Cette page contient la classe Reservation.
Il s'agit du mod�le sur lequel se base le site.
<!DOCTYPE html>
<html> -->

<?php
class Reservation{
	private $destination;
	private $nombre;
	private $assurance;
	private $names;
	private $ages;
	private $prix;
    
//Constructeur de la classe
	function __construct(){   
    $this->destination = "";
    $this->nombre = 1; //Chaque r�servation a un voyageur par d�faut
    $this->assurance = FALSE;
	$this->prix=0;
	$this->names=array();
	$this->ages=array();
  }
// Fonctions set qui permettront de modifier l'�tat de l'objet � partir de l'ext�rieur
	public function setDestination($destination){
		$this->destination = $destination;
	}
	public function setNombre($nombre){
		$this->nombre = $nombre;
	}
	public function setAssurance($assurance){
		$this->assurance = $assurance;
	}
	public function addName($name,$i){
		$this->names[$i]=$name;       //Un nom sera ajout� � la fin de la liste
	}
	public function addAge($age,$i){ // idem
		$this->ages[$i] = $age;
	}

//Fonctions get qui permettront d'acc�der � l'�tat de l'objet de l'ext�rieur
  public function getDestination(){
  return $this->destination;
  }
  public function getNombre(){
		return ($this->nombre);
	}
	public function getAssurance(){
		return ($this->assurance);
	}
	public function getNames(){
		return ($this->names);
	}
	public function getAges(){
		return ($this->ages);
  }
 //La fonction getPrix retourne le prix de la reservation
 //en se basant sur l'�tat de l'instance de la classe
  public function getPrix(){
	  $prix=0;
	  for($i=0;$i<$this->nombre;$i++){
		  if($this->ages[$i]<=12){
		  $prix+=10;
	  }
	  else{
		  $prix+=15;
	  }
	  }
	  if($this->assurance){
		  $prix+=20;
	  }
	  return $prix;
  }
}
?>
