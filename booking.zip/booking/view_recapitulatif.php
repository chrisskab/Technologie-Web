<!--Voici la vue du récapitulatif. Il s'agit d'un tableau reprenant l'état final de l'objet reservation
avant d'être envoyé vers la base de données-->
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<form class="form-signin" method="post" action="controler_recapitulatif.php">

 <h2 class="form-signin-heading">Validation des réservations</h2>
</br>

 <?php
include_once("class_reservation.php");
if(session_status()==PHP_SESSION_NONE) session_start();

?>
<table class="table table-borderless">
<thead>
<tr>
<td><b>Destination</b></td><td><b><?php echo($_SESSION['reservation']->getDestination()."</br>"); ?></b></td>
</tr>
<tr>
<td><b>Nombre de places</b></td><td><b><?php echo($_SESSION['reservation']->getNombre()."</br>"); ?></b></td>
</tr>
<tr>

</tr>
</thead>
<?php
for($i=0;$i<$_SESSION['reservation']->getNombre();$i++){
	?>
	
			<tr>
				<td>Nom </td>
				<td><?php echo($_SESSION['reservation']->getNames()[$i]);?></td>
			</tr>	
			<tr>
				<td>Age</td>
				<td><?php echo($_SESSION['reservation']->getAges()[$i]);?></td>
			</tr>
			
			<?php }


?>
<tr>
<td><b>Assurance annulation</b></td>
<td> <?php
if($_SESSION['reservation']->getAssurance()){echo('<b>OUI</b>');}
else{echo('<b>NON</b>');}
 ?>
 
 </td>
</tr>
</table>
 <table>
<tr>
<td><input class="btn btn-primary btn-block" type="submit" name="confirm" value="Confirmer"> </td>
<td><input class="btn btn-primary btn-block" type="submit" name="back" value="Retour à la page précédente"></td>
<td><input class="btn btn-primary btn-block" type="submit" name="cancel" value="Annuler la réservation"> </td>
</tr>
</table>
</form>