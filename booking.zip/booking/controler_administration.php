<?php
//Si bouton EDIT appuyé, on demande au routeur l'accès à la page des détails
if(isset($_POST['edit'])){
  
	?>
		
		<form name="form" method="post" action="router.php">
			<input type="hidden" name="page" value="detail">
            <input type="hidden" name="id" value=$_POST['edit']>
			<script type="text/javascript"> 
				document.forms["form"].submit();
			</script> 
		</form>
		
		<?php
}
//Si bouton delete appuyé, suppression dans la base de données
//De la réservation choisie.
if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    //Connexion à la base de données
    $mysqli = new mysqli("localhost", "root", "","reservation") or die("Could not select database"); //on se connecte à la base de donnée booking
if ($mysqli->connect_errno) {
  echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ")" . $mysqli->connect_error;
}
//Suppression
$sql = "DELETE 
            FROM tbooking
	    WHERE id = '$id'" ;
 $requete=$mysqli->query($sql);
 //Après suppression, on reste sur la même page.
 include 'view_administration.php';
}
//Par défaut, on affiche la page d'administration.
else{
include 'view_administration.php';
}
?>