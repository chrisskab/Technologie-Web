<!-- Cette page contient le message d'erreur à inclure sur la page d'accueil dans le cas où les conditions ne sont pas respectées-->


<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<html>
<p></p>
<div class="container">
<div class="jumbotron">
Veuillez entrer un nom pour chaque personne.</br>
Veuillez entrer un age supérieur à 0.</div></div>
<html>