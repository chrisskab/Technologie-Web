<!--Voici la vue de la page d'accueil-->
<html>
    <head>
        <title>Réservation</title>
        <meta charset="utf-8" />
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
	<div class="container">
<!--Formulaire reprenant la destination et le nombre de personnes de la réservation
Les valeurs seront envoyées au et controlées par le controleur.-->
	<form class="form-signin" method="post" action="controler_accueil.php">
 
	<p>
	<h2 class="form-signin-heading">Réservation</h2>
	<p>
        Le prix de la place est de 10 euros jusqu'à 12 ans et ensuite de 15 euros.<br /><br />
	    Le prix de l'assurance annulation est de 20 euros, quel que soit le nombre de voyageurs. <br />
        </p>
	<table>
    	<tr>
		<td>Destination </td>
		<td><input class="form-control" type="text" name="destination" value="<?php echo($reservation->getDestination());?>"/> </td>
		<!-- La valeur par défaut est celle contenue dans l'objet reservation-->
		</tr>
		<tr>
		
		<td>Nombre de places  </td>
	<td><input type="number" class="form-control" name="nombre" id="nombre" min="1" max="10" value="<?php echo($reservation->getNombre());?>"> </td>
        <!-- La valeur par défaut est celle contenue dans l'objet reservation-->
 
    </tr>
	</table>
	<label for="assurance">Assurance annulation</label>
	<input type="checkbox" name="assurance" value=TRUE <?php 
		if($reservation->getAssurance()==FALSE){echo '';} else{echo 'checked="checked"';}?> id="assurance" />
	<br/>
	<table>
	<input type="hidden" name="page" value="controler_accueil" /></br></br>
	<input class="btn btn-lg btn-primary btn-block" type="submit" name="next" value="Etape suivante" />
	<input class="btn btn-lg btn-primary btn-block" type="submit" name="cancel" value="Annuler la réservation" />
	</table>

	</p>
 	</form>
	</div>
    </body>
</html>